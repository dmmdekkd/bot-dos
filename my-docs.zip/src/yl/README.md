---
title: 友情链接
icon: laptop-code
---
```component VPCard
title: YUNZAIBOT
desc: 岩王帝君
logo: https://img.vinua.cn/images/IBCyQ.jpg
link: https://yunzaibot.cn
background: rgb(253, 230, 138, 0.15)
```

```component VPCard
title: 空空个人主页
desc: 空空
logo: https://www.kongkongwa.top/images/upload/head.jpg
link: https://www.kongkongwa.top/
background: rgb(253, 230, 138, 0.15)
```

```component VPCard
title: 洞宾小窝
desc: 欢迎来看看~
logo: http://lvtr.x406.cn/images/avatar.png?v=1731223613756
link: http://lvtr.x406.cn/
background: rgb(253, 230, 138, 0.15)
```
---
home: true
icon: home
title: 主页
heroImage: https://img.vinua.cn/images/I2qf7.png
bgImageStyle:
  background-attachment: fixed
heroText: 「一切从这里开始」
tagline: <img src="https://v1.jinrishici.com/all.svg" style="max-width:100%; ">
actions:
  - text: 开始
    icon: rocket
    link: 目录.md
    type: primary
  - text: 附页
    icon: file-alt
    link: ./portfolio.md    

highlights:
  - header: Yunzai机器人  
    highlights:
      - title: TRSS-Yunzai <code>@时雨🌌星空</code><a href="https://github.com/TimeRainStarSky" target="_blank" class="custom-link"><i class="fab fa-github" ></i></a>
      - title: Miao-Yunzai <code>@喵喵</code><a href="https://github.com/yoimiya-kokomi" target="_blank" class="custom-link"><i class="fab fa-github" ></i></a> 
      - title: YunzaiJS <code>@yunzaijs</code><a href="https://github.com/yunzaijs" target="_blank" class="custom-link"><i class="fab fa-github" ></i></a> 
  - header: 安装与配置
    features:
      - title: TRSS
        icon: robot
        details: Yunzai 应用端，支持多账号，支持协议端：go-cqhttp、ComWeChat、GSUIDCore、ICQQ、QQBot、QQ频道、微信、KOOK、Telegram、Discord、OPQBot
        link: /yunzai/TRSS/
      - title: Miao
        icon: robot
        details: 喵版 Yunzai
        link: yunzai/Yunzai/Miao/linux/

      - title: YunzaiJS
        icon: robot
        details: 支持TypeScript、具备插件npm模块化、同时实现向下兼容和向上扩展的机器人开发框架
        link: yunzai/YunzaiJS/YZJS/  
  - header: 可定制的页面
    description: 完整无障碍支持的可定制外观
    image: /assets/image/ui.svg
    bgImage: https://theme-hope-assets.vuejs.press/bg/9-light.svg
    bgImageDark: https://theme-hope-assets.vuejs.press/bg/9-dark.svg
    highlights:
      - title: 深色模式
        icon: circle-half-stroke
        details: 可以自由切换浅色模式与深色模式
        link: ./guide/interface/darkmode.html

      - title: 主题色切换
        icon: palette
        details: 支持自定义主题色并允许用户在预设的主题颜色之间切换
        link: ./guide/interface/theme-color.html

      - title: 更多
        icon: ellipsis
        details: RTL 布局，打印支持，全局按钮等
        link: ./guide/interface/others.html

  - header: 布局
    description: 一个完美的响应式布局。
    image: /assets/image/layout.svg
    bgImage: https://theme-hope-assets.vuejs.press/bg/5-light.svg
    bgImageDark: https://theme-hope-assets.vuejs.press/bg/5-dark.svg
    highlights:
      - title: 导航栏
        icon: window-maximize
        details: 完全可定制的导航栏以及改进的移动端外观
        link: ./guide/layout/navbar.html

      - title: 侧边栏
        icon: fas fa-window-maximize fa-rotate-270
        details: 从文档标题或文件结构中自动生成侧边栏
        link: ./guide/layout/sidebar.html

      - title: 幻灯片页面
        icon: person-chalkboard
        details: 添加幻灯片页面以显示你喜欢的内容
        link: ./guide/layout/slides.html

      - title: 布局增强
        icon: object-group
        details: 添加路径导航、页脚、改进的导航栏、改进的页面导航等。
        link: ./guide/layout/

      - title: 更多
        icon: ellipsis
        details: RTL 布局，打印支持，全局按钮等
        link: ./guide/interface/others.html

  - header: 新功能
    image: /assets/image/features.svg
    bgImage: https://theme-hope-assets.vuejs.press/bg/1-light.svg
    bgImageDark: https://theme-hope-assets.vuejs.press/bg/1-dark.svg
    features:
      - title: 目录页面
        icon: network-wired
        details: 自动生成目录页以及开箱即用的目录组件
        link: ./guide/feature/catalog.html

      - title: 浏览量与评论
        icon: comment-dots
        details: 配合 4 个评论服务开启阅读量统计与评论支持
        link: ./guide/feature/comment.html

      - title: 文章信息
        icon: circle-info
        details: 为你的文章添加作者、写作日期、预计阅读时间、字数统计等信息
        link: ./guide/feature/page-info.html

      - title: 文章加密
        icon: lock
        details: 你可以为你的特定页面或特定目录进行加密，以便陌生人不能随意访问它们
        link: ./guide/feature/encrypt.html

      - title: 搜索支持
        icon: search
        details: 支持 docsearch 和基于客户端的搜索
        link: ./guide/feature/search.html

      - title: 代码块
        icon: code
        details: 自定义代码块主题、行号、行高亮、复制按钮等
        link: ./guide/markdown/code/fence.html.html

      - title: 图片预览
        icon: image
        details: 像相册一样允许你浏览、缩放并分享你的页面图片
        link: ./guide/feature/photo-swipe.html

  - header: 博客
    description: 通过主题创建个人博客
    image: /assets/image/blog.svg
    bgImage: https://theme-hope-assets.vuejs.press/bg/5-light.svg
    bgImageDark: https://theme-hope-assets.vuejs.press/bg/5-dark.svg
    highlights:
      - title: 博客功能
        icon: blog
        details: 通过文章的日期、标签和分类展示文章
        link: ./guide/blog/intro.html

      - title: 博客主页
        icon: home
        details: 全新博客主页
        link: ./guide/blog/home.html

      - title: 博主信息
        icon: home
        details: 自定义名称、头像、座右铭和社交媒体链接
        link: ./guide/blog/blogger.html

      - title: 时间线
        icon: home
        details: 在时间线中浏览和通读博文
        link: ./guide/blog/timeline.html

  - header: 高级
    description: 增强站点与用户体验的高级功能
    image: /assets/image/advanced.svg
    bgImage: https://theme-hope-assets.vuejs.press/bg/4-light.svg
    bgImageDark: https://theme-hope-assets.vuejs.press/bg/4-dark.svg
    highlights:
      - title: SEO 增强
        icon: dumbbell
        details: 将最终生成的网页针对搜索引擎进行优化。
        link: ./guide/advanced/seo.html

      - title: Sitemap
        icon: sitemap
        details: 自动为你的网站生成 Sitemap
        link: ./guide/advanced/sitemap.html

      - title: Feed 支持
        icon: rss
        details: 生成你的 Feed，并通知你的用户订阅它
        link: ./guide/advanced/feed.html

      - title: PWA 支持
        icon: mobile-screen
        details: 让你的网站更像一个 APP
        link: ./guide/advanced/pwa.html


---        
## 🛠 

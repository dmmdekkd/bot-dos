---
home: true
portfolio: true
title: 作者介绍
icon: home
welcome: 在茫茫人海中，寻找从未见过的你
name: ZLMX
avatar: https://img.vinua.cn/images/I2HgL.jpg
titles:
  - 只是天空的样子，就能改变人们的心情
  - 在充满暴风雨的世界，一起勇敢地爱下去
  - 这是一个只有我和她知道，关于这世界的秘密
  - 在喜欢上你的时候，已经踏上了旅程

footer: false
---

## 简介

---

<div style="text-align: center; font-size: 0.9em; color: #777; margin-top: 60px;">
  2024 岩王帝君 版权所有 保留一切解释权利
  <a href="https://beian.miit.gov.cn/" target="_blank">蜀ICP备2024093216号-2</a>
</div>
<template>
  <div>
    <!-- 包裹 Gitee 按钮和计时器的容器 -->
    <div 
      v-if="isVisible" 
      :style="positionStyle" 
      @click="toggleVisibility" 
      class="container"
    >
      <!-- Gitee 链接图标，放置在计时器上方 -->
      <div class="gitee-link-container">
        <a 
          class="vp-repo-link" 
          href="https://gitee.com/hylexus/jt-framework" 
          target="_blank" 
          rel="noopener noreferrer" 
          aria-label="Gitee"
        >
          <GiteeIcon 
            style="width: 1.25rem; height: 1.25rem; vertical-align: middle; fill: #000000;" 
          />
        </a>
      </div>

      <!-- 计时器和导航栏 -->
      <div class="timer-container">
        <div v-if="runningTimeMessage" class="timer-message">{{ runningTimeMessage }}</div>
        <nav :class="navbarClass"></nav>
      </div>
    </div>

    <!-- 贴边箭头 -->
    <button 
      v-else 
      @click="toggleVisibility" 
      class="arrow-button" 
      :style="arrowStyle"
    >
      →
    </button>
  </div>
</template>

<script>
import { defineComponent, h, resolveComponent } from "vue";
import { GiteeIcon } from "vuepress-shared/client"; // 引入 Gitee 图标组件

export default defineComponent({
  name: "RunningTimeFooter",
  components: { GiteeIcon },
  data() {
    return {
      runningTimeMessage: "", // 当前运行时间消息
      navbarClass: "", // 导航栏样式类名
      isVisible: false, // 默认为关闭状态
    };
  },
  props: {
    startDate: {
      type: Date,
      default: () => new Date("2024-11-25"), // 起始日期
    },
    messages: {
      type: Object,
      default: () => ({
        "/": "本站已运行 :day 天 :hour 小时 :minute 分钟 :second 秒",
      }),
    },
    isTransparent: {
      type: Boolean,
      default: true, // 是否使用透明导航栏
    },
    position: {
      type: Object,
      default: () => ({
        bottom: "10px", // 默认位置为页面右下角
        right: "10px",
      }),
    },
  },
  computed: {
    positionStyle() {
      return {
        position: "fixed",
        ...this.position,
        zIndex: 1000, // 与Gitee图标层级保持一致
        cursor: "pointer",
      };
    },
    arrowStyle() {
      return {
        position: "fixed",
        bottom: this.position.bottom,
        right: "0px",
        zIndex: 1001, // 箭头按钮的层级更高
        cursor: "pointer",
      };
    },
  },
  methods: {
    toggleVisibility() {
      this.isVisible = !this.isVisible;
    },
    setupRunningTimeFooter() {
      const updateRunningTime = () => {
        const now = new Date();
        const diff = Math.floor((now - this.startDate) / 1000);

        const days = Math.floor(diff / 86400);
        const hours = Math.floor((diff % 86400) / 3600);
        const minutes = Math.floor((diff % 3600) / 60);
        const seconds = diff % 60;

        const message = this.messages["/"]
          .replace(":day", days)
          .replace(":hour", hours)
          .replace(":minute", minutes)
          .replace(":second", seconds);

        this.runningTimeMessage = message;
      };

      updateRunningTime();
      setInterval(updateRunningTime, 1000);
    },
    setupTransparentNavbar() {
      this.navbarClass = this.isTransparent ? "transparent-navbar homepage" : "navbar";
    },
  },
  mounted() {
    this.setupRunningTimeFooter();
    this.setupTransparentNavbar();
  },
});
</script>

<style scoped>
/* 包裹 Gitee 按钮和计时器的容器样式 */
.container {
  position: relative;
  z-index: 1000;
}

/* Gitee 链接图标的容器样式 */
.gitee-link-container {
  position: absolute;
  top: -35px; /* 将 Gitee 按钮放在计时器上方 */
  left: 50%;
  transform: translateX(-50%); /* 居中对齐 */
  z-index: 1000;
}

/* 计时器容器样式 */
.timer-container {
  background-color: rgba(255, 255, 255, 0.9);
  padding: 10px;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  z-index: 1000;
  position: relative;
}

/* 计时器消息样式 */
.timer-message {
  font-size: 14px;
  color: #333;
}

/* 透明导航栏样式 */
.transparent-navbar {
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
}

/* 普通导航栏样式 */
.navbar {
  background: #fff;
}

/* 贴边箭头样式 */
.arrow-button {
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 0 5px 5px 0;
  padding: 8px 12px;
  cursor: pointer;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.arrow-button:hover {
  background-color: #0056b3;
}

/* Gitee 图标链接 */
.vp-repo-link {
  display: inline-block;
  margin: auto;
  padding: 6px;
  color: var(--dark-grey);
  line-height: 1;
}

.vp-repo-link:hover, .vp-repo-link:active {
  color: var(--theme-color);
}
</style>
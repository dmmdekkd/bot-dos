export const sidebarData = {"/demo/":[]};

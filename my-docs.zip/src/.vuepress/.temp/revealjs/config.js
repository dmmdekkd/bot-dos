import { RevealJs, injectRevealJsConfig } from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-revealjs@2.0.0-rc.61_markdown-it@14.1.0_vuepress@2.0.0-rc.18_@vuepress+bundl_mhbrvmexq2efkyaztyrzoet6x4/node_modules/@vuepress/plugin-revealjs/lib/client/index.js";
import { SlidePage } from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-revealjs@2.0.0-rc.61_markdown-it@14.1.0_vuepress@2.0.0-rc.18_@vuepress+bundl_mhbrvmexq2efkyaztyrzoet6x4/node_modules/@vuepress/plugin-revealjs/lib/client/layouts/index.js";

import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/reveal.js@5.1.0/node_modules/reveal.js/dist/reveal.css";
import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-revealjs@2.0.0-rc.61_markdown-it@14.1.0_vuepress@2.0.0-rc.18_@vuepress+bundl_mhbrvmexq2efkyaztyrzoet6x4/node_modules/@vuepress/plugin-revealjs/lib/client/styles/base.css";
import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-revealjs@2.0.0-rc.61_markdown-it@14.1.0_vuepress@2.0.0-rc.18_@vuepress+bundl_mhbrvmexq2efkyaztyrzoet6x4/node_modules/@vuepress/plugin-revealjs/lib/client/styles/vars.css";
import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-revealjs@2.0.0-rc.61_markdown-it@14.1.0_vuepress@2.0.0-rc.18_@vuepress+bundl_mhbrvmexq2efkyaztyrzoet6x4/node_modules/@vuepress/plugin-revealjs/lib/client/styles/fonts/league-gothic.css";
import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-revealjs@2.0.0-rc.61_markdown-it@14.1.0_vuepress@2.0.0-rc.18_@vuepress+bundl_mhbrvmexq2efkyaztyrzoet6x4/node_modules/@vuepress/plugin-revealjs/lib/client/styles/fonts/source-sans-pro.css";
import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-revealjs@2.0.0-rc.61_markdown-it@14.1.0_vuepress@2.0.0-rc.18_@vuepress+bundl_mhbrvmexq2efkyaztyrzoet6x4/node_modules/@vuepress/plugin-revealjs/lib/client/styles/themes/auto.css";

export default {
  enhance: ({ app }) => {
    injectRevealJsConfig(app)
    app.component("RevealJs", RevealJs)
  },
  layouts: { "SlidePage": SlidePage },
};

export const useRevealJs = () => [
  import(/* webpackChunkName: "reveal" */ "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/reveal.js@5.1.0/node_modules/reveal.js/dist/reveal.esm.js"),
  import(/* webpackChunkName: "reveal" */ "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/reveal.js@5.1.0/node_modules/reveal.js/plugin/markdown/markdown.esm.js"),

];

export const redirects = JSON.parse("{}")

export const routes = Object.fromEntries([
  ["/", { loader: () => import(/* webpackChunkName: "index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/index.html.js"), meta: {"t":"主页","i":"home"} }],
  ["/portfolio.html", { loader: () => import(/* webpackChunkName: "portfolio.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/portfolio.html.js"), meta: {"t":"作者介绍","i":"home"} }],
  ["/%E7%9B%AE%E5%BD%95.html", { loader: () => import(/* webpackChunkName: "目录.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/目录.html.js"), meta: {"t":"目录","i":"laptop-code","I":false} }],
  ["/Minecraft/%E7%9B%AE%E5%BD%95.html", { loader: () => import(/* webpackChunkName: "Minecraft_目录.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/Minecraft/目录.html.js"), meta: {"t":"目录","i":"laptop-code","I":false} }],
  ["/guide/", { loader: () => import(/* webpackChunkName: "guide_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/guide/index.html.js"), meta: {"t":"link","i":"lightbulb"} }],
  ["/yl/", { loader: () => import(/* webpackChunkName: "yl_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yl/index.html.js"), meta: {"t":"友情链接","i":"laptop-code"} }],
  ["/yunzai/%E7%9B%AE%E5%BD%95.html", { loader: () => import(/* webpackChunkName: "yunzai_目录.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/目录.html.js"), meta: {"t":"目录","i":"laptop-code","I":false} }],
  ["/%E6%88%91%E7%9A%84%E6%9C%BA%E5%99%A8%E4%BA%BA/%E7%9B%AE%E5%BD%95.html", { loader: () => import(/* webpackChunkName: "我的机器人_目录.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/我的机器人/目录.html.js"), meta: {"t":"目录","i":"laptop-code","I":false} }],
  ["/Minecraft/%E8%AF%B4%E6%98%8E/", { loader: () => import(/* webpackChunkName: "Minecraft_说明_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/Minecraft/说明/index.html.js"), meta: {"t":"说明","i":"laptop-code"} }],
  ["/guide/bar/", { loader: () => import(/* webpackChunkName: "guide_bar_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/guide/bar/index.html.js"), meta: {"t":"ICQQ(第三方)","i":"lightbulb"} }],
  ["/guide/bar/baz.html", { loader: () => import(/* webpackChunkName: "guide_bar_baz.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/guide/bar/baz.html.js"), meta: {"t":"ICQQ(第三方)","i":"circle-info"} }],
  ["/guide/for/", { loader: () => import(/* webpackChunkName: "guide_for_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/guide/for/index.html.js"), meta: {"t":"QQBOT(官方)","i":"lightbulb"} }],
  ["/guide/for/ray.html", { loader: () => import(/* webpackChunkName: "guide_for_ray.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/guide/for/ray.html.js"), meta: {"t":"QQBOT(官方)","i":"circle-info"} }],
  ["/yunzai/qs/", { loader: () => import(/* webpackChunkName: "yunzai_qs_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/qs/index.html.js"), meta: {"t":"公共 Qsign","i":null} }],
  ["/%E6%88%91%E7%9A%84%E6%9C%BA%E5%99%A8%E4%BA%BA/%E6%88%91%E7%9A%84%E6%9C%BA%E5%99%A8%E4%BA%BA/", { loader: () => import(/* webpackChunkName: "我的机器人_我的机器人_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/我的机器人/我的机器人/index.html.js"), meta: {"t":"我的机器人","i":"lightbulb"} }],
  ["/%E6%88%91%E7%9A%84%E6%9C%BA%E5%99%A8%E4%BA%BA/%E6%9C%BA%E5%99%A8%E4%BA%BA%E5%8A%9F%E8%83%BD/", { loader: () => import(/* webpackChunkName: "我的机器人_机器人功能_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/我的机器人/机器人功能/index.html.js"), meta: {"t":"机器人功能","i":"lightbulb"} }],
  ["/Minecraft/%E5%90%AF%E5%8A%A8%E5%99%A8/%E5%90%AF%E5%8A%A8%E5%99%A8/", { loader: () => import(/* webpackChunkName: "Minecraft_启动器_启动器_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/Minecraft/启动器/启动器/index.html.js"), meta: {"t":"暂定","i":"lightbulb"} }],
  ["/yunzai/TRSS/Windows/", { loader: () => import(/* webpackChunkName: "yunzai_TRSS_Windows_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/TRSS/Windows/index.html.js"), meta: {"t":"Windows","i":"lightbulb"} }],
  ["/yunzai/TRSS/liunx/", { loader: () => import(/* webpackChunkName: "yunzai_TRSS_liunx_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/TRSS/liunx/index.html.js"), meta: {"t":"liunx","i":"lightbulb"} }],
  ["/yunzai/TRSS/%E5%AE%89%E5%8D%93/", { loader: () => import(/* webpackChunkName: "yunzai_TRSS_安卓_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/TRSS/安卓/index.html.js"), meta: {"t":"Termux","i":"lightbulb"} }],
  ["/yunzai/YunzaiJS/YZJS/", { loader: () => import(/* webpackChunkName: "yunzai_YunzaiJS_YZJS_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/YunzaiJS/YZJS/index.html.js"), meta: {"t":"Yunzai JS","i":"lightbulb"} }],
  ["/yunzai/%E6%88%91%E7%9A%84%E6%8F%92%E4%BB%B6/plugin/", { loader: () => import(/* webpackChunkName: "yunzai_我的插件_plugin_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/我的插件/plugin/index.html.js"), meta: {"t":"plugin类","i":"lightbulb"} }],
  ["/yunzai/%E6%88%91%E7%9A%84%E6%8F%92%E4%BB%B6/%E5%8D%95js/", { loader: () => import(/* webpackChunkName: "yunzai_我的插件_单js_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/我的插件/单js/index.html.js"), meta: {"t":"单js","i":"lightbulb"} }],
  ["/yunzai/%E8%A7%A3%E5%86%B3%E5%8A%9E%E6%B3%95/%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98/", { loader: () => import(/* webpackChunkName: "yunzai_解决办法_常见问题_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/解决办法/常见问题/index.html.js"), meta: {"t":"常见问题","i":"lightbulb"} }],
  ["/yunzai/%E8%A7%A3%E5%86%B3%E5%8A%9E%E6%B3%95/%E7%99%BB%E5%BD%95/", { loader: () => import(/* webpackChunkName: "yunzai_解决办法_登录_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/解决办法/登录/index.html.js"), meta: {"t":"登录教程","i":"lightbulb"} }],
  ["/yunzai/%E8%A7%A3%E5%86%B3%E5%8A%9E%E6%B3%95/%E9%97%AE%E9%A2%98/", { loader: () => import(/* webpackChunkName: "yunzai_解决办法_问题_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/解决办法/问题/index.html.js"), meta: {"t":"遇到问题？","i":"lightbulb"} }],
  ["/yunzai/Yunzai/Miao/linux/", { loader: () => import(/* webpackChunkName: "yunzai_Yunzai_Miao_linux_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/Yunzai/Miao/linux/index.html.js"), meta: {"t":"Yunzai JS","i":"lightbulb"} }],
  ["/404.html", { loader: () => import(/* webpackChunkName: "404.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/404.html.js"), meta: {"t":""} }],
  ["/Minecraft/", { loader: () => import(/* webpackChunkName: "Minecraft_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/Minecraft/index.html.js"), meta: {"t":"Minecraft"} }],
  ["/yunzai/", { loader: () => import(/* webpackChunkName: "yunzai_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/index.html.js"), meta: {"t":"Yunzai"} }],
  ["/%E6%88%91%E7%9A%84%E6%9C%BA%E5%99%A8%E4%BA%BA/", { loader: () => import(/* webpackChunkName: "我的机器人_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/我的机器人/index.html.js"), meta: {"t":"我的机器人"} }],
  ["/Minecraft/%E5%90%AF%E5%8A%A8%E5%99%A8/", { loader: () => import(/* webpackChunkName: "Minecraft_启动器_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/Minecraft/启动器/index.html.js"), meta: {"t":"启动器"} }],
  ["/yunzai/TRSS/", { loader: () => import(/* webpackChunkName: "yunzai_TRSS_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/TRSS/index.html.js"), meta: {"t":"TRSS"} }],
  ["/yunzai/YunzaiJS/", { loader: () => import(/* webpackChunkName: "yunzai_YunzaiJS_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/YunzaiJS/index.html.js"), meta: {"t":"Yunzai JS"} }],
  ["/yunzai/%E6%88%91%E7%9A%84%E6%8F%92%E4%BB%B6/", { loader: () => import(/* webpackChunkName: "yunzai_我的插件_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/我的插件/index.html.js"), meta: {"t":"我的插件"} }],
  ["/yunzai/%E8%A7%A3%E5%86%B3%E5%8A%9E%E6%B3%95/", { loader: () => import(/* webpackChunkName: "yunzai_解决办法_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/解决办法/index.html.js"), meta: {"t":"解决办法"} }],
  ["/yunzai/Yunzai/Miao/", { loader: () => import(/* webpackChunkName: "yunzai_Yunzai_Miao_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/Yunzai/Miao/index.html.js"), meta: {"t":"Miao"} }],
  ["/yunzai/Yunzai/", { loader: () => import(/* webpackChunkName: "yunzai_Yunzai_index.html" */"/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/Yunzai/index.html.js"), meta: {"t":"Yunzai"} }],
]);

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateRoutes) {
    __VUE_HMR_RUNTIME__.updateRoutes(routes)
  }
  if (__VUE_HMR_RUNTIME__.updateRedirects) {
    __VUE_HMR_RUNTIME__.updateRedirects(redirects)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ routes, redirects }) => {
    __VUE_HMR_RUNTIME__.updateRoutes(routes)
    __VUE_HMR_RUNTIME__.updateRedirects(redirects)
  })
}

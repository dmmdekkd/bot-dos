import * as clientConfig0 from '/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/shiki/config.js'
import * as clientConfig1 from '/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/sass-palette/load-hope.js'
import * as clientConfig2 from '/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/components/config.js'
import * as clientConfig3 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-active-header-links@2.0.0-rc.55_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@_kyycre4xyzhkawxeyngstngzce/node_modules/@vuepress/plugin-active-header-links/lib/client/config.js'
import * as clientConfig4 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-catalog@2.0.0-rc.56_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc.18__j2wvq7z54b2d24ffzxs4bueu5i/node_modules/@vuepress/plugin-catalog/lib/client/config.js'
import * as clientConfig5 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-back-to-top@2.0.0-rc.56_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc_xs4vwo4vjw6h63ar633xxxjloy/node_modules/@vuepress/plugin-back-to-top/lib/client/config.js'
import * as clientConfig6 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-nprogress@2.0.0-rc.56_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc.1_ebu4kuqpugithethcta2oanrwy/node_modules/@vuepress/plugin-nprogress/lib/client/config.js'
import * as clientConfig7 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-theme-data@2.0.0-rc.56_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc._5bdcyi73jaxlyanej7k7fjtzmm/node_modules/@vuepress/plugin-theme-data/lib/client/config.js'
import * as clientConfig8 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-comment@2.0.0-rc.56_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc.18__mlymdho7bnun4tmoamwcsggdoy/node_modules/@vuepress/plugin-comment/lib/client/config.js'
import * as clientConfig9 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-copy-code@2.0.0-rc.56_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc.1_afc37kgny7gyoofqhmvw7yg52i/node_modules/@vuepress/plugin-copy-code/lib/client/config.js'
import * as clientConfig10 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-hint@2.0.0-rc.56_markdown-it@14.1.0_vue@3.5.13_vuepress@2.0.0-rc.18_d53ewshqzfukm356lg3lctpdj4/node_modules/@vuepress/plugin-markdown-hint/lib/client/config.js'
import * as clientConfig11 from '/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/markdown-image/client.js'
import * as clientConfig12 from '/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/markdown-tab/config.js'
import * as clientConfig13 from '/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/md-enhance/config.js'
import * as clientConfig14 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-photo-swipe@2.0.0-rc.56_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc_2hljj3bwhvtjw5edx5rro57zf4/node_modules/@vuepress/plugin-photo-swipe/lib/client/config.js'
import * as clientConfig15 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-search-pro@2.0.0-rc.59_sass-embedded@1.81.0_vuepress@2.0.0-rc.18_@vuepress+bu_fwjjta7jzrwp7cfawmttlf6gse/node_modules/vuepress-plugin-search-pro/lib/client/config.js'
import * as clientConfig16 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-redirect@2.0.0-rc.56_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc.18_ly6rzcgv2vjuxk4e6cp2l4mygi/node_modules/@vuepress/plugin-redirect/lib/client/config.js'
import * as clientConfig17 from '/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/theme-hope/config.js'
import * as clientConfig18 from '/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-oh-my-live2d@0.19.3_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc.18_@_vovcxykiqx2cfywjp67xtsqwv4/node_modules/vuepress-plugin-oh-my-live2d/dist/client/config.js'
import * as clientConfig19 from '/data/data/com.termux/files/home/my-docs/src/.vuepress/client.ts'

export const clientConfigs = [
  clientConfig0,
  clientConfig1,
  clientConfig2,
  clientConfig3,
  clientConfig4,
  clientConfig5,
  clientConfig6,
  clientConfig7,
  clientConfig8,
  clientConfig9,
  clientConfig10,
  clientConfig11,
  clientConfig12,
  clientConfig13,
  clientConfig14,
  clientConfig15,
  clientConfig16,
  clientConfig17,
  clientConfig18,
  clientConfig19,
].map((m) => m.default).filter(Boolean)

import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-image@2.0.0-rc.56_markdown-it@14.1.0_vuepress@2.0.0-rc.18_@vuepress_2ob2jw3yep5g4rfezbotddyh6e/node_modules/@vuepress/plugin-markdown-image/lib/client/styles/figure.css"


<template><div><p>// .vuepress/pages/visitor-counter.md</p>
<h1 id="访客统计" tabindex="-1"><a class="header-anchor" href="#访客统计"><span>访客统计</span></a></h1>
<MyComponent /></div></template>


<script setup>
import MyComponent from "@MyComponent";
import VisitorCounter from "@VisitorCounter";
</script>
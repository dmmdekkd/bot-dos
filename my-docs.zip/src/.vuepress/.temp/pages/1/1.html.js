import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/1/1.html.vue"
const data = JSON.parse("{\"path\":\"/1/1.html\",\"title\":\"最新变化\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"最新变化\",\"icon\":\"changelog\",\"description\":\"::: hint Header 预设\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/1/1.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"最新变化\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"::: hint Header 预设\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:image\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/img/qq-icon.png\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"最新变化\\\",\\\"image\\\":[\\\"https://vuepress-theme-hope-docs-demo.netlify.app/img/qq-icon.png\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"\\\",\\\"url\\\":\\\"1.png\\\"}]}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0.3,\"words\":90},\"filePathRelative\":\"1/1.md\",\"autoDesc\":true,\"excerpt\":\"<p>::: hint Header 预设 </p>\\n\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

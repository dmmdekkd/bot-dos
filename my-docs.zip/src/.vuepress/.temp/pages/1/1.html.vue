<template><div><p>::: hint Header 预设 <Badge vertical="top" text="新功能" type="tip"/></p>
<MyCarousel :imgList="['/img/2024.1.8/headersPreset.png','/img/qq-icon.png']" /><p>Header 预设支持创建不同的 Header 分组，管理各自的请求头，通过下拉选择轻松快捷得添加预设的 Header 参数。</p>
<p>:::</p>
<p>::: hint Binary 支持 <Badge vertical="top" text="新功能" type="tip"/><br>
<img src="/img/qq-icon.png" alt="" loading="lazy"></p>
<p>支持 Binary 格式上传</p>
<p>:::</p>
</div></template>



import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/qs/index.html.vue"
const data = JSON.parse("{\"path\":\"/qs/\",\"title\":\"公共 Qsign\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"公共 Qsign\",\"icon\":null,\"description\":\"http://api.lzqxcd.cn/?key=3448585471 https://api.qsign.icu/?key=Free 9070 1 https://qsign.trpgbot.com/ 9095 2 https://qsign-v3.trpgbot.com/ 9056 3 https://qsign.chahuyun.cn/ 908...\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/qs/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"公共 Qsign\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"http://api.lzqxcd.cn/?key=3448585471 https://api.qsign.icu/?key=Free 9070 1 https://qsign.trpgbot.com/ 9095 2 https://qsign-v3.trpgbot.com/ 9056 3 https://qsign.chahuyun.cn/ 908...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"公共 Qsign\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"\\\",\\\"url\\\":\\\"1.png\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"ZLMX 签名服务\",\"slug\":\"zlmx-签名服务\",\"link\":\"#zlmx-签名服务\",\"children\":[]},{\"level\":2,\"title\":\"寒暄 签名服务\",\"slug\":\"寒暄-签名服务\",\"link\":\"#寒暄-签名服务\",\"children\":[]},{\"level\":2,\"title\":\"zhaodice 签名服务\",\"slug\":\"zhaodice-签名服务\",\"link\":\"#zhaodice-签名服务\",\"children\":[]}],\"readingTime\":{\"minutes\":0.52,\"words\":156},\"filePathRelative\":\"qs/README.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

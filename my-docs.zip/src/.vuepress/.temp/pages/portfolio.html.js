import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/portfolio.html.vue"
const data = JSON.parse("{\"path\":\"/portfolio.html\",\"title\":\"作者介绍\",\"lang\":\"zh-CN\",\"frontmatter\":{\"home\":true,\"portfolio\":true,\"title\":\"作者介绍\",\"icon\":\"home\",\"welcome\":\"在茫茫人海中，寻找从未见过的你\",\"name\":\"ZLMX\",\"avatar\":\"https://img.vinua.cn/images/I2HgL.jpg\",\"titles\":[\"只是天空的样子，就能改变人们的心情\",\"在充满暴风雨的世界，一起勇敢地爱下去\",\"这是一个只有我和她知道，关于这世界的秘密\",\"在喜欢上你的时候，已经踏上了旅程\"],\"footer\":false,\"description\":\"简介 2024 岩王帝君 版权所有 保留一切解释权利 蜀ICP备2024093216号-2\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/portfolio.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"Sixflowers\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"作者介绍\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"简介 2024 岩王帝君 版权所有 保留一切解释权利 蜀ICP备2024093216号-2\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"作者介绍\\\",\\\"description\\\":\\\"简介 2024 岩王帝君 版权所有 保留一切解释权利 蜀ICP备2024093216号-2\\\"}\"]]},\"headers\":[{\"level\":2,\"title\":\"简介\",\"slug\":\"简介\",\"link\":\"#简介\",\"children\":[]}],\"readingTime\":{\"minutes\":0.49,\"words\":147},\"filePathRelative\":\"portfolio.md\",\"autoDesc\":true,\"excerpt\":\"<h2>简介</h2>\\n<hr>\\n<div style=\\\"text-align: center; font-size: 0.9em; color: #777; margin-top: 60px;\\\">\\n  2024 岩王帝君 版权所有 保留一切解释权利\\n  <a href=\\\"https://beian.miit.gov.cn/\\\" target=\\\"_blank\\\">蜀ICP备2024093216号-2</a>\\n</div>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

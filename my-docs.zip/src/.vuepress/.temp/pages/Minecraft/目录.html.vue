<template><div><div class="catalog-display-container">
  <Catalog base='/wdsj' />
</div>
</div></template>



import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/guide/bar/index.html.vue"
const data = JSON.parse("{\"path\":\"/guide/bar/\",\"title\":\"ICQQ(第三方)\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"ICQQ(第三方)\",\"icon\":\"lightbulb\",\"description\":\"介绍 基于TRSS YunzaiQQ机器人 介绍 这是晴酱机器人 机器人功能介绍 暂定 详情 机器人群聊 机器人主页 ...\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/guide/bar/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"Sixflowers\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"ICQQ(第三方)\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"介绍 基于TRSS YunzaiQQ机器人 介绍 这是晴酱机器人 机器人功能介绍 暂定 详情 机器人群聊 机器人主页 ...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"ICQQ(第三方)\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"介绍\",\"slug\":\"介绍\",\"link\":\"#介绍\",\"children\":[]},{\"level\":2,\"title\":\"介绍\",\"slug\":\"介绍-1\",\"link\":\"#介绍-1\",\"children\":[]},{\"level\":2,\"title\":\"详情\",\"slug\":\"详情\",\"link\":\"#详情\",\"children\":[]}],\"readingTime\":{\"minutes\":0.27,\"words\":80},\"filePathRelative\":\"guide/bar/README.md\",\"autoDesc\":true,\"excerpt\":\"<h2>介绍</h2>\\n<p>基于TRSS YunzaiQQ机器人</p>\\n<h2>介绍</h2>\\n<ul>\\n<li>这是晴酱机器人</li>\\n</ul>\\n <img src=\\\"https://img.vinua.cn/images/IgbbC.jpg\\\" align=\\\"“left”\\\" width=\\\"100\\\">\\n<ul>\\n<li>机器人功能介绍</li>\\n</ul>\\n<p>暂定</p>\\n<h2>详情</h2>\\n<ul>\\n<li><a href=\\\"http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&amp;k=WmLOA9p-q0mgS0Ap_AplHl8c-rDQb68L&amp;authKey=is9rjIUFeEsbKfCeYptZZYolPjW%2FmAXMfMXuDwotyLiyibkR4b7yoTSUtJ%2FY509j&amp;noverify=0&amp;group_code=317849294\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">机器人群聊</a></li>\\n<li><a href=\\\"https://qm.qq.com/q/ulB9179HAk\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">机器人主页</a></li>\\n<li><a href=\\\"/guide/bar/baz.html\\\" target=\\\"_blank\\\">更多内容</a></li>\\n<li>...</li>\\n</ul>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

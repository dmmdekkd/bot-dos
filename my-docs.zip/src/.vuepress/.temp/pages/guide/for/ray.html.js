import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/guide/for/ray.html.vue"
const data = JSON.parse("{\"path\":\"/guide/for/ray.html\",\"title\":\"QQBOT(官方)\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"QQBOT(官方)\",\"icon\":\"circle-info\",\"description\":\"功能详情...(待写)\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/guide/for/ray.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"Sixflowers\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"QQBOT(官方)\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"功能详情...(待写)\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"QQBOT(官方)\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"\\\"}]}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0.05,\"words\":14},\"filePathRelative\":\"guide/for/ray.md\",\"autoDesc\":true,\"excerpt\":\"<p>功能详情...(待写)</p>\\n\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

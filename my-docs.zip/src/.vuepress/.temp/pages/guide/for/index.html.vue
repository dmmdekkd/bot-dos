<template><div><h2 id="介绍" tabindex="-1"><a class="header-anchor" href="#介绍"><span>介绍</span></a></h2>
<p>基于TRDS Yunzai的QQBOT机器人</p>
<h2 id="介绍-1" tabindex="-1"><a class="header-anchor" href="#介绍-1"><span>介绍</span></a></h2>
<ul>
<li>这是晴酱机器人</li>
</ul>
 <img src="https://img.vinua.cn/images/IgbbC.jpg"  align = “left”  width="100" />
<ul>
<li>机器人功能介绍</li>
</ul>
<p>暂定</p>
<h2 id="详情" tabindex="-1"><a class="header-anchor" href="#详情"><span>详情</span></a></h2>
<ul>
<li>
<p><a href="http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&amp;k=WmLOA9p-q0mgS0Ap_AplHl8c-rDQb68L&amp;authKey=is9rjIUFeEsbKfCeYptZZYolPjW%2FmAXMfMXuDwotyLiyibkR4b7yoTSUtJ%2FY509j&amp;noverify=0&amp;group_code=317849294" target="_blank" rel="noopener noreferrer">机器人群聊</a></p>
</li>
<li>
<p><a href="https://bot.q.qq.com/s/917433cnh?id=102131063" target="_blank" rel="noopener noreferrer">机器人主页</a></p>
</li>
<li>
<p><a href="https://qun.qq.com/qunpro/robot/share?robot_appid=102131063" target="_blank" rel="noopener noreferrer">频道添加</a></p>
</li>
<li>
<p><RouteLink to="/guide/for/ray.html">更多内容</RouteLink></p>
</li>
<li>
<p>...</p>
</li>
</ul>
</div></template>



<template><div><SiteInfo
  name="QQ机器人"
  desc="点击添加"
  url="https://bot.q.qq.com/s/917433cnh?id=102131063"
  logo="https://img.vinua.cn/images/IgbbC.jpg"
  preview="https://img.vinua.cn/images/I2Vkl.jpg"
/>
<SiteInfo
  name="官方群聊"
  desc="点击加群"
  url="http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=ccIiho4YYV0fl3Oxx_XG22h56qJ6HvQ5&authKey=03JWw3SkDCgY60pCwV8empuTfB39cmEJ04KZa%2FVHhgiO1P7JT1xJ0fqG%2F3tSgH2R&noverify=0&group_code=317849294"
  logo="https://img.vinua.cn/images/I2COi.png"
  preview="https://img.vinua.cn/images/I2MS1.jpg"
/>
<SiteInfo
  name="联系作者"
  desc="点击添加"
  url="https://qm.qq.com/q/vAN1O22vB0"
  logo="https://img.vinua.cn/images/I2COi.png"
  preview="https://img.vinua.cn/images/I2MS1.jpg"
/>
</div></template>



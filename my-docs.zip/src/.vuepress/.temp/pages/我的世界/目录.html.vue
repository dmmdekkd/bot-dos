<template><div><div class="catalog-display-container">
  <Catalog base='/我的世界' />
</div>
</div></template>



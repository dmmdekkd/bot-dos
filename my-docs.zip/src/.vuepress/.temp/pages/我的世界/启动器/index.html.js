import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/我的世界/启动器/index.html.vue"
const data = JSON.parse("{\"path\":\"/%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C/%E5%90%AF%E5%8A%A8%E5%99%A8/\",\"title\":\"启动器\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"启动器\",\"article\":false,\"feed\":false,\"sitemap\":false,\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C/%E5%90%AF%E5%8A%A8%E5%99%A8/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"启动器\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"启动器\\\"}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0,\"words\":1},\"filePathRelative\":null}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/我的世界/介绍/index.html.vue"
const data = JSON.parse("{\"path\":\"/%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C/%E4%BB%8B%E7%BB%8D/\",\"title\":\"说明\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"说明\",\"icon\":\"lightbulb\",\"gitInclude\":[]},\"headers\":[],\"readingTime\":{\"minutes\":0.02,\"words\":5},\"filePathRelative\":\"我的世界/介绍/README.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

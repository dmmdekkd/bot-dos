import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/我的世界/我的世界启动器/我的世界/index.html.vue"
const data = JSON.parse("{\"path\":\"/%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C/%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C%E5%90%AF%E5%8A%A8%E5%99%A8/%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C/\",\"title\":\"我的世界\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"我的世界\",\"icon\":\"lightbulb\",\"gitInclude\":[]},\"headers\":[],\"readingTime\":{\"minutes\":0.02,\"words\":7},\"filePathRelative\":\"我的世界/我的世界启动器/我的世界/README.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

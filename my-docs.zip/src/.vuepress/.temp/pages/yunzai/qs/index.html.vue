<template><div><hr>
<MyComponent /><hr>
</div></template>


<script setup>
import MyComponent from "@MyComponent";
</script>
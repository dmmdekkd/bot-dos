import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/解决办法/index.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/%E8%A7%A3%E5%86%B3%E5%8A%9E%E6%B3%95/\",\"title\":\"解决办法\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"解决办法\",\"article\":false,\"feed\":false,\"sitemap\":false,\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/yunzai/%E8%A7%A3%E5%86%B3%E5%8A%9E%E6%B3%95/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"Sixflowers\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"解决办法\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"解决办法\\\"}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0,\"words\":1},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

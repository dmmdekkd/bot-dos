import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/liunx/index.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/liunx/\",\"title\":\"liunx\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"liunx\",\"icon\":\"lightbulb\",\"description\":\"准备工作 购买服务器 腾讯云 腾讯云是腾讯多年技术沉淀的云计算服务平台，提供300+款产品和全栈解决方案，覆盖大数据、计算、人工智能、容器、存储、网络、微信生态等多个领域 阿里云 阿里云—阿里巴巴集团旗下公司，是全球领先的云计算及人工智能科技公司。提供云服务器、云数据库、云安全、云存储、企业应用及行业解决方案服务 华为云 华为云是华为旗下的云计算服务平...\",\"gitInclude\":[]},\"headers\":[{\"level\":2,\"title\":\"准备工作\",\"slug\":\"准备工作\",\"link\":\"#准备工作\",\"children\":[{\"level\":3,\"title\":\"购买服务器\",\"slug\":\"购买服务器\",\"link\":\"#购买服务器\",\"children\":[]},{\"level\":3,\"title\":\"服务器系统选择\",\"slug\":\"服务器系统选择\",\"link\":\"#服务器系统选择\",\"children\":[]}]},{\"level\":2,\"title\":\"开始安装\",\"slug\":\"开始安装\",\"link\":\"#开始安装\",\"children\":[{\"level\":3,\"title\":\"换源\",\"slug\":\"换源\",\"link\":\"#换源\",\"children\":[]},{\"level\":3,\"title\":\"选择清华源\",\"slug\":\"选择清华源\",\"link\":\"#选择清华源\",\"children\":[]},{\"level\":3,\"title\":\"软件源是否使用 HTTP 协议? [Y]\",\"slug\":\"软件源是否使用-http-协议-y\",\"link\":\"#软件源是否使用-http-协议-y\",\"children\":[]},{\"level\":3,\"title\":\"是否跳过更新软件包? [Y]\",\"slug\":\"是否跳过更新软件包-y\",\"link\":\"#是否跳过更新软件包-y\",\"children\":[]},{\"level\":3,\"title\":\"是否清理已下载的软件包缓存? [Y]\",\"slug\":\"是否清理已下载的软件包缓存-y\",\"link\":\"#是否清理已下载的软件包缓存-y\",\"children\":[]},{\"level\":3,\"title\":\"[完成] 安装完成\",\"slug\":\"完成-安装完成\",\"link\":\"#完成-安装完成\",\"children\":[]}]},{\"level\":2,\"title\":\"安装Docker\",\"slug\":\"安装docker\",\"link\":\"#安装docker\",\"children\":[{\"level\":3,\"title\":\"脚本安装Docker\",\"slug\":\"脚本安装docker\",\"link\":\"#脚本安装docker\",\"children\":[]},{\"level\":3,\"title\":\"是否安装最新版本的 Docker Engine? [Y]\",\"slug\":\"是否安装最新版本的-docker-engine-y\",\"link\":\"#是否安装最新版本的-docker-engine-y\",\"children\":[]},{\"level\":3,\"title\":\"请选择并输入你想使用的 Docker CE 源 [7]\",\"slug\":\"请选择并输入你想使用的-docker-ce-源-7\",\"link\":\"#请选择并输入你想使用的-docker-ce-源-7\",\"children\":[]},{\"level\":3,\"title\":\"请选择并输入你想使用的 Docker Registry 源 [13]\",\"slug\":\"请选择并输入你想使用的-docker-registry-源-13\",\"link\":\"#请选择并输入你想使用的-docker-registry-源-13\",\"children\":[]},{\"level\":3,\"title\":\"[完成] 安装完成\",\"slug\":\"完成-安装完成-1\",\"link\":\"#完成-安装完成-1\",\"children\":[]}]},{\"level\":2,\"title\":\"安装TRSS容器\",\"slug\":\"安装trss容器\",\"link\":\"#安装trss容器\",\"children\":[{\"level\":3,\"title\":\"使用脚本安装\",\"slug\":\"使用脚本安装\",\"link\":\"#使用脚本安装\",\"children\":[]},{\"level\":3,\"title\":\"容器安装完成，启动命令\",\"slug\":\"容器安装完成-启动命令\",\"link\":\"#容器安装完成-启动命令\",\"children\":[]},{\"level\":3,\"title\":\"如何登录？\",\"slug\":\"如何登录\",\"link\":\"#如何登录\",\"children\":[]}]}],\"readingTime\":{\"minutes\":2.11,\"words\":632},\"filePathRelative\":\"yunzai/liunx/README.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/问题/index.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/%E9%97%AE%E9%A2%98/\",\"title\":\"遇到问题？\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"遇到问题？\",\"icon\":\"lightbulb\",\"description\":\"加我\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/yunzai/%E9%97%AE%E9%A2%98/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"遇到问题？\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"加我\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"遇到问题？\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"\\\",\\\"url\\\":\\\"1.png\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"加我\",\"slug\":\"加我\",\"link\":\"#加我\",\"children\":[]}],\"readingTime\":{\"minutes\":0.33,\"words\":99},\"filePathRelative\":\"yunzai/问题/README.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

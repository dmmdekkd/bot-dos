import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/安卓/index.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/%E5%AE%89%E5%8D%93/\",\"title\":\"Termux\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Termux\",\"icon\":\"lightbulb\",\"description\":\"教程 教程\",\"gitInclude\":[]},\"headers\":[{\"level\":2,\"title\":\"教程\",\"slug\":\"教程\",\"link\":\"#教程\",\"children\":[]}],\"readingTime\":{\"minutes\":0.11,\"words\":34},\"filePathRelative\":\"yunzai/安卓/README.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

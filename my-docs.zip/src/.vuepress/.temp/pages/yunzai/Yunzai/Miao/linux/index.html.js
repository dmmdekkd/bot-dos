import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/Yunzai/Miao/linux/index.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/Yunzai/Miao/linux/\",\"title\":\"Yunzai JS\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Yunzai JS\",\"icon\":\"lightbulb\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/yunzai/Yunzai/Miao/linux/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"Sixflowers\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"Yunzai JS\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"Yunzai JS\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"\\\"}]}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0.02,\"words\":5},\"filePathRelative\":\"yunzai/Yunzai/Miao/linux/README.md\",\"excerpt\":\"\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

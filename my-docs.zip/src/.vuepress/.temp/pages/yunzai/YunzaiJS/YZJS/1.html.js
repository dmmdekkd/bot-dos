import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/YunzaiJS/YZJS/1.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/YunzaiJS/YZJS/1.html\",\"title\":\"Yunzai v4\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Yunzai v4\",\"icon\":\"lightbulb\",\"gitInclude\":[]},\"headers\":[],\"readingTime\":{\"minutes\":0.02,\"words\":5},\"filePathRelative\":\"yunzai/YunzaiJS/YZJS/1.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

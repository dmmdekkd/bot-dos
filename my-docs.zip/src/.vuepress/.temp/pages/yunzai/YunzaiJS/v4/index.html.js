import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/YunzaiJS/v4/index.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/YunzaiJS/v4/\",\"title\":\"Yunzai v4\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Yunzai v4\",\"icon\":\"lightbulb\",\"gitInclude\":[]},\"headers\":[],\"readingTime\":{\"minutes\":0.02,\"words\":5},\"filePathRelative\":\"yunzai/YunzaiJS/v4/README.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

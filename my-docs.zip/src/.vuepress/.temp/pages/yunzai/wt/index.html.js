import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/wt/index.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/wt/\",\"title\":\"遇到问题？\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"遇到问题？\",\"icon\":\"lightbulb\",\"description\":\"加我\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/yunzai/wt/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"遇到问题？\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"加我\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"遇到问题？\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"岩王帝君 版权所有 保留一切解释权利\\\",\\\"url\\\":\\\"https://img.vinua.cn/images/I221D.png\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"加我\",\"slug\":\"加我\",\"link\":\"#加我\",\"children\":[]}],\"readingTime\":{\"minutes\":0.33,\"words\":99},\"filePathRelative\":\"yunzai/wt/README.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/anzhuo/index.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/anzhuo/\",\"title\":\"Termux\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Termux\",\"icon\":\"lightbulb\",\"description\":\"教程 教程\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/yunzai/anzhuo/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"Termux\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"教程 教程\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"Termux\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"岩王帝君 版权所有 保留一切解释权利\\\",\\\"url\\\":\\\"https://img.vinua.cn/images/I221D.png\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"教程\",\"slug\":\"教程\",\"link\":\"#教程\",\"children\":[]}],\"readingTime\":{\"minutes\":0.11,\"words\":34},\"filePathRelative\":\"yunzai/anzhuo/README.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

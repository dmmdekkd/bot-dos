import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/yunzai/登录/index.html.vue"
const data = JSON.parse("{\"path\":\"/yunzai/%E7%99%BB%E5%BD%95/\",\"title\":\"登录教程\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"登录教程\",\"icon\":\"lightbulb\",\"gitInclude\":[]},\"headers\":[],\"readingTime\":{\"minutes\":0.02,\"words\":7},\"filePathRelative\":\"yunzai/登录/README.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

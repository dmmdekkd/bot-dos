<template><div><h2 id="教程" tabindex="-1"><a class="header-anchor" href="#教程"><span>教程</span></a></h2>
<h3 id="liunx教程🐧" tabindex="-1"><a class="header-anchor" href="#liunx教程🐧"><span>liunx教程🐧</span></a></h3>
<hr style="border: none; height: 3px; background-image: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); margin: 20px 0;">
<blockquote>
<p><strong>概括</strong></p>
<ol>
<li>购买服务器</li>
<li>系统选择</li>
<li>开始安装</li>
<li>安装Docker</li>
<li>安装TRSS容器</li>
</ol>
</blockquote>
<VPBanner
  title="TRSS Script"
  content=""
  :actions='[
    {
      text: "开始教程",
      link:"/trss/liunx/README.md",
    },
    {
      text: "仓库",
      link: "https://github.com/TimeRainStarSky/TRSS_Script",
      type: "default",
    },
  ]'
/>
<hr style="border: none; height: 3px; background-image: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); margin: 20px 0;">
<h3 id="termux教程📱" tabindex="-1"><a class="header-anchor" href="#termux教程📱"><span>Termux教程📱</span></a></h3>
<hr style="border: none; height: 3px; background-image: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); margin: 20px 0;">
<blockquote>
<p><strong>概括</strong><br>
还没写呢 <Badge text="构建中" type="warning" /> <Badge text="ZLMX" color="grey" /></p>
</blockquote>
<VPBanner
  title="TRSS Script"
  content=""
  :actions='[
    {
      text: "开始教程",
      link:"/trss/安卓/README.md",
    },
    {
      text: "仓库",
      link: "https://github.com/TimeRainStarSky/TRSS_Script",
      type: "default",
    },
  ]'
/>
<hr style="border: none; height: 3px; background-image: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); margin: 20px 0;">
<h3 id="windows教程💻" tabindex="-1"><a class="header-anchor" href="#windows教程💻"><span>Windows教程💻</span></a></h3>
<hr style="border: none; height: 3px; background-image: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); margin: 20px 0;">
<blockquote>
<p><strong>概括</strong></p>
<ol>
<li>安装MYSY2</li>
<li>执行TRSS Script</li>
<li>启动</li>
</ol>
</blockquote>
<VPBanner
  title="TRSS Script"
  content=""
  :actions='[
    {
      text: "开始教程",
      link:"/trss/Windows/README.md",
    },
    {
      text: "仓库",
      link: "https://github.com/TimeRainStarSky/TRSS_Script",
      type: "default",
    },
  ]'
/>
<hr style="border: none; height: 3px; background-image: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); margin: 20px 0;">
<h3 id="遇到问题-🤔" tabindex="-1"><a class="header-anchor" href="#遇到问题-🤔"><span>遇到问题？🤔</span></a></h3>
<ul>
<li><RouteLink to="/trss/%E9%97%AE%E9%A2%98/">点击进入</RouteLink></li>
<li>...</li>
</ul>
<h3 id="常见问题" tabindex="-1"><a class="header-anchor" href="#常见问题"><span>常见问题</span></a></h3>
</div></template>



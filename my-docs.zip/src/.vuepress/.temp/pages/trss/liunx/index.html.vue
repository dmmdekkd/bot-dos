<template><div><h2 id="准备工作" tabindex="-1"><a class="header-anchor" href="#准备工作"><span>准备工作</span></a></h2>
<h3 id="购买服务器" tabindex="-1"><a class="header-anchor" href="#购买服务器"><span>购买服务器</span></a></h3>
<p><a href="https://cloud.tencent.com" target="_blank" rel="noopener noreferrer">腾讯云</a></p>
<blockquote>
<p>腾讯云是腾讯多年技术沉淀的云计算服务平台，提供300+款产品和全栈解决方案，覆盖大数据、计算、人工智能、容器、存储、网络、微信生态等多个领域</p>
</blockquote>
<p><a href="https://www.aliyun.com" target="_blank" rel="noopener noreferrer">阿里云</a></p>
<blockquote>
<p>阿里云—阿里巴巴集团旗下公司，是全球领先的云计算及人工智能科技公司。提供云服务器、云数据库、云安全、云存储、企业应用及行业解决方案服务</p>
</blockquote>
<p><a href="https://activity.huaweicloud.com" target="_blank" rel="noopener noreferrer">华为云</a></p>
<blockquote>
<p>华为云是华为旗下的云计算服务平台，为各行业客户提供弹性云服务器、对象存储、文字识别、内容分发网络等多种云产品和解决方案</p>
</blockquote>
<div class="hint-container warning">
<p class="hint-container-title">注意</p>
<p>当然你也可以选择其他的</p>
</div>
<h3 id="服务器系统选择" tabindex="-1"><a class="header-anchor" href="#服务器系统选择"><span>服务器系统选择</span></a></h3>
<Card title="本人推荐系统">
  Ubuntu22，Debian 12
</Card>
<h2 id="开始安装" tabindex="-1"><a class="header-anchor" href="#开始安装"><span>开始安装</span></a></h2>
<div class="hint-container tip">
<p class="hint-container-title">提示</p>
<p>安装中遇到看不懂的回车即可</p>
</div>
<h3 id="换源" tabindex="-1"><a class="header-anchor" href="#换源"><span>换源</span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="shiki" data-ext="bash" data-title="bash" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre v-pre class="shiki shiki-themes one-light one-dark-pro vp-code"><code><span class="line"><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">bash</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> &#x3C;(</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">curl</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> -sSL</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> https://linuxmirrors.cn/main.sh)</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div><h3 id="选择清华源" tabindex="-1"><a class="header-anchor" href="#选择清华源"><span>选择清华源</span></a></h3>
<img src="/images/TRSS/Linux/1/1.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h3 id="软件源是否使用-http-协议-y" tabindex="-1"><a class="header-anchor" href="#软件源是否使用-http-协议-y"><span>软件源是否使用 HTTP 协议? [Y]</span></a></h3>
<img src="/images/TRSS/Linux/1/2.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h3 id="是否跳过更新软件包-y" tabindex="-1"><a class="header-anchor" href="#是否跳过更新软件包-y"><span>是否跳过更新软件包? [Y]</span></a></h3>
<img src="/images/TRSS/Linux/1/3.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h3 id="是否清理已下载的软件包缓存-y" tabindex="-1"><a class="header-anchor" href="#是否清理已下载的软件包缓存-y"><span>是否清理已下载的软件包缓存? [Y]</span></a></h3>
<img src="/images/TRSS/Linux/1/4.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h3 id="完成-安装完成" tabindex="-1"><a class="header-anchor" href="#完成-安装完成"><span>[完成] 安装完成</span></a></h3>
<img src="/images/TRSS/Linux/1/5.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h2 id="安装docker" tabindex="-1"><a class="header-anchor" href="#安装docker"><span>安装Docker</span></a></h2>
<h3 id="脚本安装docker" tabindex="-1"><a class="header-anchor" href="#脚本安装docker"><span>脚本安装Docker</span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="shiki" data-ext="bash" data-title="bash" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre v-pre class="shiki shiki-themes one-light one-dark-pro vp-code"><code><span class="line"><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">bash</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> &#x3C;(</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">curl</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> -sSL</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> https://linuxmirrors.cn/docker.sh)</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div><h3 id="是否安装最新版本的-docker-engine-y" tabindex="-1"><a class="header-anchor" href="#是否安装最新版本的-docker-engine-y"><span>是否安装最新版本的 Docker Engine? [Y]</span></a></h3>
<img src="/images/TRSS/Linux/2/1.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h3 id="请选择并输入你想使用的-docker-ce-源-7" tabindex="-1"><a class="header-anchor" href="#请选择并输入你想使用的-docker-ce-源-7"><span>请选择并输入你想使用的 Docker CE 源 [7]</span></a></h3>
<img src="/images/TRSS/Linux/2/2.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h3 id="请选择并输入你想使用的-docker-registry-源-13" tabindex="-1"><a class="header-anchor" href="#请选择并输入你想使用的-docker-registry-源-13"><span>请选择并输入你想使用的 Docker Registry 源 [13]</span></a></h3>
<img src="/images/TRSS/Linux/2/3.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h3 id="完成-安装完成-1" tabindex="-1"><a class="header-anchor" href="#完成-安装完成-1"><span>[完成] 安装完成</span></a></h3>
<img src="/images/TRSS/Linux/2/4.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h2 id="安装trss容器" tabindex="-1"><a class="header-anchor" href="#安装trss容器"><span>安装TRSS容器</span></a></h2>
<h3 id="使用脚本安装" tabindex="-1"><a class="header-anchor" href="#使用脚本安装"><span>使用脚本安装</span></a></h3>
<CodeTabs id="100" :data='[{"id":"国内推荐"},{"id":"国外推荐"},{"id":"备用方法"},{"id":"字体安装"}]'>
<template #title0="{ value, isActive }">国内推荐</template>
<template #title1="{ value, isActive }">国外推荐</template>
<template #title2="{ value, isActive }">备用方法</template>
<template #title3="{ value, isActive }">字体安装</template>
<template #tab0="{ value, isActive }">
<div class="language-bash line-numbers-mode" data-highlighter="shiki" data-ext="bash" data-title="bash" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre v-pre class="shiki shiki-themes one-light one-dark-pro vp-code"><code><span class="line"><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">DKURL</span><span style="--shiki-light:#383A42;--shiki-dark:#56B6C2">=</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">docker.fxxk.dedyn.io</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF"> bash</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> &#x3C;(</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">curl</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> -L</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> gitee.com/TimeRainStarSky/TRSS_AllBot/raw/main/Install-Docker.sh)</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div></template>
<template #tab1="{ value, isActive }">
<div class="language-bash line-numbers-mode" data-highlighter="shiki" data-ext="bash" data-title="bash" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre v-pre class="shiki shiki-themes one-light one-dark-pro vp-code"><code><span class="line"><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">bash</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> &#x3C;(</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">curl</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> -L</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> gitee.com/TimeRainStarSky/TRSS_AllBot/raw/main/Install-Docker.sh)</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div></template>
<template #tab2="{ value, isActive }">
<div class="language-bash line-numbers-mode" data-highlighter="shiki" data-ext="bash" data-title="bash" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre v-pre class="shiki shiki-themes one-light one-dark-pro vp-code"><code><span class="line"><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">bash</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> &#x3C;(</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">curl</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> -L</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> gitee.com/qianzhi11_admin/my-website/raw/master/TRSS_AllBot.sh)</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div></template>
<template #tab3="{ value, isActive }">
<div class="language-bash line-numbers-mode" data-highlighter="shiki" data-ext="bash" data-title="bash" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre v-pre class="shiki shiki-themes one-light one-dark-pro vp-code"><code><span class="line"><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">pacman</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> -Syu</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> --noconfirm</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> glibc</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div></template>
</CodeTabs>
<h3 id="容器安装完成-启动命令" tabindex="-1"><a class="header-anchor" href="#容器安装完成-启动命令"><span>容器安装完成，启动命令</span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="shiki" data-ext="bash" data-title="bash" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre v-pre class="shiki shiki-themes one-light one-dark-pro vp-code"><code><span class="line"><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">tsab</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div><img src="/images/TRSS/Linux/3/1.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h3 id="如何登录" tabindex="-1"><a class="header-anchor" href="#如何登录"><span>如何登录？</span></a></h3>
<p>无</p>
</div></template>



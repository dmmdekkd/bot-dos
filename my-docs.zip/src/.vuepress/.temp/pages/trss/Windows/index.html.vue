<template><div><h2 id="准备工作" tabindex="-1"><a class="header-anchor" href="#准备工作"><span>准备工作</span></a></h2>
<h3 id="安装mysy2" tabindex="-1"><a class="header-anchor" href="#安装mysy2"><span>安装MYSY2</span></a></h3>
<VPBanner
  title="安装MYSY2"
  content=""
  :actions='[
    {
      text: "立即下载",
      link:"https://gitee.com/qianzhi11_admin/docs/releases/download/1.0/msys2-x86_64-20240727.exe",
    },
  ]'
/>
<h2 id="开始" tabindex="-1"><a class="header-anchor" href="#开始"><span>开始</span></a></h2>
<h3 id="一直点next" tabindex="-1"><a class="header-anchor" href="#一直点next"><span>一直点NEXT</span></a></h3>
<img src="/images/TRSS/Windows/1/1.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h3 id="执行trss-script" tabindex="-1"><a class="header-anchor" href="#执行trss-script"><span>执行TRSS Script</span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="shiki" data-ext="bash" data-title="bash" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre v-pre class="shiki shiki-themes one-light one-dark-pro vp-code"><code><span class="line"><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">bash</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> &#x3C;(</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">curl</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> -L</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> gitee.com/TimeRainStarSky/TRSS_AllBot/raw/main/Install.sh)</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div><h3 id="脚本安装完成-启动命令tsab" tabindex="-1"><a class="header-anchor" href="#脚本安装完成-启动命令tsab"><span>脚本安装完成，启动命令tsab</span></a></h3>
<img src="/images/TRSS/Windows/1/2.png" alt="1" style="border-radius: 10px; box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);">
<h2 id="启动命令" tabindex="-1"><a class="header-anchor" href="#启动命令"><span>启动命令</span></a></h2>
<div class="language-bash line-numbers-mode" data-highlighter="shiki" data-ext="bash" data-title="bash" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre v-pre class="shiki shiki-themes one-light one-dark-pro vp-code"><code><span class="line"><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">tsab</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div></div></template>



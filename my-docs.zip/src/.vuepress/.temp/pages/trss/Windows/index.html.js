import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/trss/Windows/index.html.vue"
const data = JSON.parse("{\"path\":\"/trss/Windows/\",\"title\":\"Windows\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Windows\",\"icon\":\"lightbulb\",\"description\":\"准备工作 安装MYSY2\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/trss/Windows/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"Windows\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"准备工作 安装MYSY2\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"Windows\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"\\\",\\\"url\\\":\\\"1.png\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"准备工作\",\"slug\":\"准备工作\",\"link\":\"#准备工作\",\"children\":[{\"level\":3,\"title\":\"安装MYSY2\",\"slug\":\"安装mysy2\",\"link\":\"#安装mysy2\",\"children\":[]}]},{\"level\":2,\"title\":\"开始\",\"slug\":\"开始\",\"link\":\"#开始\",\"children\":[{\"level\":3,\"title\":\"一直点NEXT\",\"slug\":\"一直点next\",\"link\":\"#一直点next\",\"children\":[]},{\"level\":3,\"title\":\"执行TRSS Script\",\"slug\":\"执行trss-script\",\"link\":\"#执行trss-script\",\"children\":[]},{\"level\":3,\"title\":\"脚本安装完成，启动命令tsab\",\"slug\":\"脚本安装完成-启动命令tsab\",\"link\":\"#脚本安装完成-启动命令tsab\",\"children\":[]}]},{\"level\":2,\"title\":\"启动命令\",\"slug\":\"启动命令\",\"link\":\"#启动命令\",\"children\":[]}],\"readingTime\":{\"minutes\":0.33,\"words\":99},\"filePathRelative\":\"trss/Windows/README.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/trss/index.html.vue"
const data = JSON.parse("{\"path\":\"/trss/\",\"title\":\"TRSS Script\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"TRSS Script\",\"icon\":\"lightbulb\",\"description\":\"教程 liunx教程🐧 概括 购买服务器 系统选择 开始安装 安装Docker 安装TRSS容器\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/trss/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"TRSS Script\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"教程 liunx教程🐧 概括 购买服务器 系统选择 开始安装 安装Docker 安装TRSS容器\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"TRSS Script\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"\\\",\\\"url\\\":\\\"1.png\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"教程\",\"slug\":\"教程\",\"link\":\"#教程\",\"children\":[{\"level\":3,\"title\":\"liunx教程🐧\",\"slug\":\"liunx教程🐧\",\"link\":\"#liunx教程🐧\",\"children\":[]},{\"level\":3,\"title\":\"Termux教程📱\",\"slug\":\"termux教程📱\",\"link\":\"#termux教程📱\",\"children\":[]},{\"level\":3,\"title\":\"Windows教程💻\",\"slug\":\"windows教程💻\",\"link\":\"#windows教程💻\",\"children\":[]},{\"level\":3,\"title\":\"遇到问题？🤔\",\"slug\":\"遇到问题-🤔\",\"link\":\"#遇到问题-🤔\",\"children\":[]},{\"level\":3,\"title\":\"常见问题\",\"slug\":\"常见问题\",\"link\":\"#常见问题\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.98,\"words\":295},\"filePathRelative\":\"trss/README.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/我的世界目录.html.vue"
const data = JSON.parse("{\"path\":\"/%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C%E7%9B%AE%E5%BD%95.html\",\"title\":\"目录\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"目录\",\"index\":false,\"icon\":\"laptop-code\",\"category\":[\"ZLMX&\"],\"gitInclude\":[]},\"headers\":[],\"readingTime\":{\"minutes\":0.08,\"words\":23},\"filePathRelative\":\"我的世界目录.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/visitor-counter.html.vue"
const data = JSON.parse("{\"path\":\"/visitor-counter.html\",\"title\":\"访客统计\",\"lang\":\"zh-CN\",\"frontmatter\":{\"description\":\"// .vuepress/pages/visitor-counter.md 访客统计\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/visitor-counter.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"访客统计\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"// .vuepress/pages/visitor-counter.md 访客统计\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"访客统计\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"岩王帝君 版权所有 保留一切解释权利\\\",\\\"url\\\":\\\"https://img.vinua.cn/images/I221D.png\\\"}]}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0.07,\"words\":20},\"filePathRelative\":\"visitor-counter.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

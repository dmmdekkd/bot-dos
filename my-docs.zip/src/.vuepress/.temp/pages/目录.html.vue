<template><div><div class="catalog-display-container">
  <Catalog base='/' />
</div>
</div></template>



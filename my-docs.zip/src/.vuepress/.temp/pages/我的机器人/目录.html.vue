<template><div><div class="catalog-display-container">
  <Catalog base='/我的机器人' />
</div>
</div></template>



import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/我的机器人/机器人功能.html.vue"
const data = JSON.parse("{\"path\":\"/%E6%88%91%E7%9A%84%E6%9C%BA%E5%99%A8%E4%BA%BA/%E6%9C%BA%E5%99%A8%E4%BA%BA%E5%8A%9F%E8%83%BD.html\",\"title\":\"机器人功能\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"机器人功能\",\"icon\":\"lightbulb\",\"gitInclude\":[]},\"headers\":[],\"readingTime\":{\"minutes\":0.03,\"words\":8},\"filePathRelative\":\"我的机器人/机器人功能.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

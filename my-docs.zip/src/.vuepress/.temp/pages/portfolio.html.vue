<template><div><h2 id="简介" tabindex="-1"><a class="header-anchor" href="#简介"><span>简介</span></a></h2>
<hr>
<div style="text-align: center; font-size: 0.9em; color: #777; margin-top: 60px;">
  2024 岩王帝君 版权所有 保留一切解释权利
  <a href="https://beian.miit.gov.cn/" target="_blank">蜀ICP备2024093216号-2</a>
</div></div></template>



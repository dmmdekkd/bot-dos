import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/wdsj/启动器/启动器/index.html.vue"
const data = JSON.parse("{\"path\":\"/wdsj/%E5%90%AF%E5%8A%A8%E5%99%A8/%E5%90%AF%E5%8A%A8%E5%99%A8/\",\"title\":\"暂定\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"暂定\",\"icon\":\"lightbulb\",\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/wdsj/%E5%90%AF%E5%8A%A8%E5%99%A8/%E5%90%AF%E5%8A%A8%E5%99%A8/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"暂定\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"暂定\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"\\\",\\\"url\\\":\\\"1.png\\\"}]}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0.02,\"words\":5},\"filePathRelative\":\"wdsj/启动器/启动器/README.md\",\"excerpt\":\"\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

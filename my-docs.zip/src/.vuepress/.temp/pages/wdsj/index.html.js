import comp from "/data/data/com.termux/files/home/my-docs/src/.vuepress/.temp/pages/wdsj/index.html.vue"
const data = JSON.parse("{\"path\":\"/wdsj/\",\"title\":\"Wdsj\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Wdsj\",\"article\":false,\"feed\":false,\"sitemap\":false,\"gitInclude\":[],\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/wdsj/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"ZLMX\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"Wdsj\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"Wdsj\\\"}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0,\"words\":1},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}

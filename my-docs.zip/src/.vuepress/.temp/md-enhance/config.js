import ChartJS from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/components/ChartJS.js";
import CodeDemo from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/components/CodeDemo.js";
import MdDemo from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/components/MdDemo.js";
import ECharts from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/components/ECharts.js";
import { injectEChartsConfig } from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client//index.js";
import FlowChart from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/components/FlowChart.js";
import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/styles/footnote.scss";
import Mermaid from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/components/Mermaid.js";
import { injectMermaidConfig } from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client//index.js";
import Playground from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/components/Playground.js";
import { defineAsyncComponent } from "vue";
import { LoadingIcon } from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@vuepress+helper@2.0.0-rc.56_vuepress@2.0.0-rc.18_@vuepress+bundler-vite@2.0.0-rc.18_@types+n_nbeeump3sg46qcsiflowyhlkhq/node_modules/@vuepress/helper/lib/client/index.js";
import { injectSandpackConfig } from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/index.js";
import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/@mdit+plugin-spoiler@0.13.1_markdown-it@14.1.0/node_modules/@mdit/plugin-spoiler/spoiler.css";
import "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/styles/tasklist.scss";
import VuePlayground from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/components/VuePlayground.js";
import { injectVuePlaygroundConfig } from "/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/index.js";

export default {
  enhance: ({ app }) => {
    app.component("ChartJS", ChartJS)
    app.component("CodeDemo", CodeDemo);
    app.component("MdDemo", MdDemo);
    app.component("ECharts", ECharts);
    injectEChartsConfig(app);
    app.component("FlowChart", FlowChart);
    injectMermaidConfig(app);
    app.component("Mermaid", Mermaid);
    app.component("Playground", Playground);
    injectSandpackConfig(app);
    app.component(
      "SandPack",
      defineAsyncComponent({
        loader: () => import("/data/data/com.termux/files/home/my-docs/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.59_@vue+repl@4.4.2_chart.js@4.4.6_echarts@5.5.1_flowchart_plsnjx5haude6bpi6rkuba7seq/node_modules/vuepress-plugin-md-enhance/lib/client/components/SandPack.js"),
        loadingComponent: LoadingIcon,
      })
    );
    injectVuePlaygroundConfig(app);
    app.component("VuePlayground", VuePlayground);
  },
};

declare global {
  const __VUEPRESS_SSR__: boolean;
}

export {};

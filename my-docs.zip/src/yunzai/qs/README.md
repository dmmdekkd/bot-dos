---
title: 公共 Qsign
icon: 
---

---

<MyComponent />

<script setup>
import MyComponent from "@MyComponent";
</script>
---
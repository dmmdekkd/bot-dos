---
title: 遇到问题？
icon: lightbulb
---

## 加我

<InfoCard>
  <a href="https://qm.qq.com/q/2sVYgBgTa0" target="_blank" style="display: block; text-align: center; padding: 16px; 
            background-color: #0073e6; color: white; font-size: 18px; font-weight: bold; 
            border-radius: 8px; text-decoration: none; transition: transform 0.3s ease; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
    点击这里加我
  </a>
  <p style="text-align: center; font-size: 14px; color: #555; margin-top: 8px;">QQ: 3448585471</p>
</InfoCard>

<style>
a:hover {
    transform: scale(1.05); /* 鼠标悬浮时按钮略微放大 */
}
</style>
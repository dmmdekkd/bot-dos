---
title: Termux
icon: lightbulb
---

## 教程<Badge text="新" type="tip" /> <Badge text=" ZLMX" color="grey" />

教程 <Badge text="构建中" type="warning" /> <Badge text=" ZLMX" color="grey" />
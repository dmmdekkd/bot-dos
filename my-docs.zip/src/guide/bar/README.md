---
title: ICQQ(第三方)
icon: lightbulb
---

## 介绍

基于TRSS YunzaiQQ机器人

## 介绍

- 这是晴酱机器人

 <img src="https://img.vinua.cn/images/IgbbC.jpg"  align = “left”  width="100" />

- 机器人功能介绍

 暂定

## 详情

- [机器人群聊](http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=WmLOA9p-q0mgS0Ap_AplHl8c-rDQb68L&authKey=is9rjIUFeEsbKfCeYptZZYolPjW%2FmAXMfMXuDwotyLiyibkR4b7yoTSUtJ%2FY509j&noverify=0&group_code=317849294)
- [机器人主页](https://qm.qq.com/q/ulB9179HAk)
- [更多内容](baz.md)
- ...

---
title: QQBOT(官方)
icon: lightbulb
---

## 介绍

基于TRDS Yunzai的QQBOT机器人

## 介绍

- 这是晴酱机器人

 <img src="https://img.vinua.cn/images/IgbbC.jpg"  align = “left”  width="100" />

- 机器人功能介绍

 暂定

## 详情

- [机器人群聊](http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=WmLOA9p-q0mgS0Ap_AplHl8c-rDQb68L&authKey=is9rjIUFeEsbKfCeYptZZYolPjW%2FmAXMfMXuDwotyLiyibkR4b7yoTSUtJ%2FY509j&noverify=0&group_code=317849294)

- [机器人主页](https://bot.q.qq.com/s/917433cnh?id=102131063)

- [频道添加](https://qun.qq.com/qunpro/robot/share?robot_appid=102131063)
  
- [更多内容](ray.md)
- ...

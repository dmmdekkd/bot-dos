import{_ as m}from"./MyIcon.vue_vue_type_style_index_0_lang-Cz5l-jrv.js";import"./app-DgoeIx6D.js";export{m as default};
